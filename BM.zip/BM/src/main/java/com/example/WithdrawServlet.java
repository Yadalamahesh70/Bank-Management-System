package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/WithdrawServlet")
public class WithdrawServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");
        double amount = Double.parseDouble(request.getParameter("amount"));

        if (amount <= 0) {
            response.sendRedirect("customerDashboard.jsp?errorMsg=Invalid amount.");
            return;
        }

        if (accountNumber == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        Connection con = null;
        PreparedStatement pstSelect = null;
        PreparedStatement pstUpdate = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.initializeDatabase();
            con.setAutoCommit(false); // Start transaction

            // Retrieve current balance
            String queryBalance = "SELECT balance FROM customers WHERE account_number = ?";
            pstSelect = con.prepareStatement(queryBalance);
            pstSelect.setString(1, accountNumber);
            rs = pstSelect.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");
                if (currentBalance >= amount) {
                    double newBalance = currentBalance - amount;

                    // Update balance in database
                    String updateQuery = "UPDATE customers SET balance = ? WHERE account_number = ?";
                    pstUpdate = con.prepareStatement(updateQuery);
                    pstUpdate.setDouble(1, newBalance);
                    pstUpdate.setString(2, accountNumber);
                    pstUpdate.executeUpdate();

                    // Record transaction
                    String recordTransactionQuery = "INSERT INTO transactions (account_number, amount, transaction_date, transaction_type) VALUES (?, ?, ?, 'withdrawal')";
                    PreparedStatement pstInsert = con.prepareStatement(recordTransactionQuery);
                    pstInsert.setString(1, accountNumber);
                    pstInsert.setDouble(2, amount);
                    pstInsert.setDate(3, new java.sql.Date(new Date().getTime()));
                    pstInsert.executeUpdate();

                    con.commit(); // Commit transaction

                    response.sendRedirect("op.jsp?successMsg=Withdrawal successful.");
                } else {
                    response.sendRedirect("customerDashboard.jsp?errorMsg=Insufficient balance.");
                }
            } else {
                response.sendRedirect("customerLogin.jsp");
            }
        } catch (SQLException | ClassNotFoundException e) {
            try {
                if (con != null) {
                    con.rollback(); // Rollback transaction on error
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            response.sendRedirect("customerDashboard.jsp?errorMsg=Database error occurred. Please try again later.");
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (pstSelect != null)
                    pstSelect.close();
                if (pstUpdate != null)
                    pstUpdate.close();
                if (con != null)
                    con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
