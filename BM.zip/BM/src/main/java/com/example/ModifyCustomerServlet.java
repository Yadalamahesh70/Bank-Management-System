package com.example;

import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/modifyCustomer")
public class ModifyCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            String accountNumber = request.getParameter("accountNumber");
            String fullName = request.getParameter("fullName");
            String address = request.getParameter("address");
            String mobileNumber = request.getParameter("mobileNumber");
            String email = request.getParameter("email");
            String idProof = request.getParameter("idProof");
            String accountType = request.getParameter("accountType");
            String dobStr = request.getParameter("dob");
            String isClosedStr = request.getParameter("isClosed");
            
            // Parse date
            Date dob = new SimpleDateFormat("yyyy-MM-dd").parse(dobStr);

            // Parse isClosed
            int isClosed = Integer.parseInt(isClosedStr);

            CustomerDAO customerDAO = new CustomerDAO();
            Customer customer = new Customer();
            customer.setAccountNumber(accountNumber);
            customer.setFullName(fullName);
            customer.setAddress(address);
            customer.setMobileNumber(mobileNumber);
            customer.setEmail(email);
            customer.setIdProof(idProof);
            customer.setAccountType(accountType);
            customer.setDob(dob);
            customer.setIsClosed(isClosed);

            boolean updated = customerDAO.updateCustomer(customer);

            if (updated) {
                request.setAttribute("message", "Customer details have been successfully updated.");
            } else {
                request.setAttribute("message", "Failed to update customer details.");
            }
            request.getRequestDispatcher("modifyCustomer.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("message", "Error: " + e.getMessage());
            request.getRequestDispatcher("modifyCustomer.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
