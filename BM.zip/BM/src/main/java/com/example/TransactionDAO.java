package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public List<Transaction> getTransactionsByAccountNumber(String accountNumber, int start, int total) throws SQLException, ClassNotFoundException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE account_number = ? LIMIT ?, ?";

        try (Connection conn = DatabaseConnection.initializeDatabase();
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, accountNumber);
            pst.setInt(2, start);
            pst.setInt(3, total);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getDate("transaction_date"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transactions.add(transaction);
            }
        }
        return transactions;
    }
}
