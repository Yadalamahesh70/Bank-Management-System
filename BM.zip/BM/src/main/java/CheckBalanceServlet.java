import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.DatabaseConnection;

@WebServlet("/CheckBalanceServlet")
public class CheckBalanceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");

        if (accountNumber == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.initializeDatabase();
            String query = "SELECT * FROM customers WHERE account_number = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, accountNumber);
            rs = pst.executeQuery();

            if (rs.next()) {
                double balance = rs.getDouble("balance");
                session.setAttribute("balance", balance); // Store balance in session
                response.sendRedirect("customerDashboard.jsp"); // Redirect to customer dashboard
            } else {
                response.sendRedirect("customerLogin.jsp");
                // Redirect if account not found
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
