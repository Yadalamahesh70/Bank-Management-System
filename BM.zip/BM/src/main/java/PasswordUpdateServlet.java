import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.DatabaseConnection;

@WebServlet("/PasswordUpdateServlet")
public class PasswordUpdateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve account number from session
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");

        if (accountNumber == null) {
            // Redirect to login page if session doesn't contain account number
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        // Retrieve new password and confirm password from form data
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        // Validate password fields
        if (newPassword == null || confirmPassword == null || !newPassword.equals(confirmPassword)) {
            // Redirect back to dashboard with error message if passwords do not match or newPassword is null
            response.sendRedirect("customerDashboard.jsp?error=Passwords do not match or new password is empty.");
            return;
        }

        // Update password in the database
        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = DatabaseConnection.initializeDatabase();
            String query = "UPDATE customers SET password = ? WHERE account_number = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, newPassword);
            pst.setString(2, accountNumber);
            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {
                // Password updated successfully
                response.sendRedirect("customerDashboard.jsp?msg=Password updated successfully.");
            } else {
                // Failed to update password
                response.sendRedirect("customerDashboard.jsp?error=Failed to update password. Please try again.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("customerDashboard.jsp?error=Database error occurred. Please try again later.");
        } finally {
            try {
                // Close PreparedStatement and Connection
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
