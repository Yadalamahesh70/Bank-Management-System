import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewProfileServlet")
public class ViewProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");

        if (accountNumber == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        try {
            Connection conn = DatabaseConnection.initializeDatabase();
            String query = "SELECT * FROM customers WHERE account_number = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, accountNumber);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                request.setAttribute("fullName", rs.getString("full_name"));
                request.setAttribute("address", rs.getString("address"));
                request.setAttribute("mobileNo", rs.getString("mobile_no"));
                request.setAttribute("email", rs.getString("email"));
                request.setAttribute("accountType", rs.getString("account_type"));
                request.setAttribute("balance", rs.getDouble("balance"));
                request.setAttribute("dob", rs.getDate("dob"));
                request.setAttribute("idProof", rs.getString("id_proof"));
                request.setAttribute("accountNumber", rs.getString("account_number"));
            }

            RequestDispatcher dispatcher = request.getRequestDispatcher("viewProfile.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMsg", "Unable to retrieve profile information.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("customerDashboard.jsp");
            dispatcher.forward(request, response);
        }
    }
}
