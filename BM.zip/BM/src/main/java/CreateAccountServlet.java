import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String address = request.getParameter("address");
        String mobileNo = request.getParameter("mobileNo");
        String email = request.getParameter("email");
        String accountType = request.getParameter("accountType");
        int balance = Integer.parseInt(request.getParameter("balance"));
        String dob = request.getParameter("dob");
        String idProof = request.getParameter("idProof");

        try {
            Connection connection = DatabaseConnection.initializeDatabase();

            // Check if ID Proof already exists
            String checkIdProofSql = "SELECT * FROM customers WHERE id_proof = ?";
            PreparedStatement checkIdProofStmt = connection.prepareStatement(checkIdProofSql);
            checkIdProofStmt.setString(1, idProof);
            ResultSet idProofResult = checkIdProofStmt.executeQuery();

            if (idProofResult.next()) {
                // ID Proof already exists
                request.setAttribute("errorMessage", "ID Proof already exists in the database.");
                request.getRequestDispatcher("createaccount.jsp").forward(request, response);
            } else {
                // ID Proof is unique, proceed with account creation
                String accountNumber = generateAccountNumber();
                String password = generatePassword();

                String insertCustomerSql = "INSERT INTO customers (full_name, address, mobile_no, email, account_type, balance, dob, id_proof, account_number, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement insertCustomerStmt = connection.prepareStatement(insertCustomerSql);
                insertCustomerStmt.setString(1, fullName);
                insertCustomerStmt.setString(2, address);
                insertCustomerStmt.setString(3, mobileNo);
                insertCustomerStmt.setString(4, email);
                insertCustomerStmt.setString(5, accountType);
                insertCustomerStmt.setInt(6, balance);
                insertCustomerStmt.setString(7, dob);
                insertCustomerStmt.setString(8, idProof);
                insertCustomerStmt.setString(9, accountNumber);
                insertCustomerStmt.setString(10, password);

                insertCustomerStmt.executeUpdate();

                // Set attributes for success message and account details
                request.setAttribute("successMessage", "Customer account created successfully!");
                request.setAttribute("accountNumber", accountNumber);
                request.setAttribute("password", password);

                // Redirect to newaccount.jsp
                request.getRequestDispatcher("newaccount.jsp").forward(request, response);
            }

            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while creating the account. Please try again.");
            request.getRequestDispatcher("createaccount.jsp").forward(request, response);
        }
    }

    private String generateAccountNumber() {
        SecureRandom random = new SecureRandom();
        int length = 11 + random.nextInt(6);
        StringBuilder accountNumber = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            accountNumber.append(random.nextInt(10));
        }
        return accountNumber.toString();
    }

    private String generatePassword() {
        SecureRandom random = new SecureRandom();
        int length = 8 + random.nextInt(5);
        StringBuilder password = new StringBuilder(length);
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (int i = 0; i < length; i++) {
            password.append(characters.charAt(random.nextInt(characters.length())));
        }
        return password.toString();
    }
}