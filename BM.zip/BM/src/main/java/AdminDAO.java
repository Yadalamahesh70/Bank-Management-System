

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO {
    public boolean authenticateAdmin(String username, String password) throws SQLException, ClassNotFoundException {
        boolean isAuthenticated = false;
        Connection connection = DatabaseConnection.initializeDatabase();

        String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, username);
        statement.setString(2, password);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            isAuthenticated = true;
        }

        resultSet.close();
        statement.close();
        connection.close();

        return isAuthenticated;
    }
}
