import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("admin") == null) {
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        // Add headers to prevent caching
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "0");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.initializeDatabase();
            String query = "SELECT account_number, full_name, address, mobile_no, email, account_type, dob, id_proof, is_closed FROM customers";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            request.setAttribute("customers", rs);
            request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("admin") == null) {
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        // Add headers to prevent caching
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "0");

        String action = request.getParameter("action");
        String accountNumber = request.getParameter("accountNumber");

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DatabaseConnection.initializeDatabase();

            if ("Delete".equals(action)) {
                String query = "DELETE FROM customers WHERE account_number = ?";
                ps = conn.prepareStatement(query);
                ps.setString(1, accountNumber);
                ps.executeUpdate();
            } else if ("Update".equals(action)) {
                String fullName = request.getParameter("fullName");
                String address = request.getParameter("address");
                String mobileNo = request.getParameter("mobileNo");
                String email = request.getParameter("email");
                String accountType = request.getParameter("accountType");
                String dob = request.getParameter("dob");
                String idProof = request.getParameter("idProof");
                String isClosed = request.getParameter("isClosed");

                String query = "UPDATE customers SET full_name = ?, address = ?, mobile_no = ?, email = ?, account_type = ?, dob = ?, id_proof = ?, is_closed = ? WHERE account_number = ?";
                ps = conn.prepareStatement(query);
                ps.setString(1, fullName);
                ps.setString(2, address);
                ps.setString(3, mobileNo);
                ps.setString(4, email);
                ps.setString(5, accountType);
                ps.setString(6, dob);
                ps.setString(7, idProof);
                ps.setString(8, isClosed);
                ps.setString(9, accountNumber);
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Redirect back to the dashboard
        response.sendRedirect("adminDashboard.jsp");
    }
}
